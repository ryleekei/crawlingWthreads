/* CS 270 final Project Fall 2022
 * Skeleton code for a directory "crawler" using threads.
 */
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h> // for opendir, readdir
#include <unistd.h> // 
#include <stdlib.h> // for exit()
#include "fifoq.h"  // API for fifoq_t
#include <string.h>

/* XXXXX THESE CONSTANTS SHOULD NOT BE CHANGED */
#define MAXLINE 256
#define NAMESIZE 256
#define MAXTHREADS 8

// use this if you want...
void die(char *s) {
  perror(s);
  exit(9);
}

/****************** Shared variables ***************************/
char *searchstring;  // string to look for in files
fifoq_t jobq;        // FIFO queue of file names
int total;   // total # of occurrences found so far
int nfiles;  //number of files processed
int checkline(char *line, char *target);
pthread_mutex_t turnlock;
pthread_cond_t myturn;

/* Also needed:
 *   mutex for controlling access to the ints above.
 *   condition variable for workers to signal main thread.
 ****************************************************************/
int checkline(char *line, char *target)
{
	int count = 0;
	char *lp; //line pointer 
	char *tp; //target pointer
	char *start = line; //start is beginning of line
	
	for(;;) 
	{
		lp = start; //point at beginning of line
		tp = target; //point at beginning of target string

		while( *lp && *tp && *lp == *tp)
		{	//advance both pointers
			lp++;
			tp++;
	       	}

		if (*tp == 0 && *lp != 0)
		{
			count++; //increment count
			start = lp; //set new start to where target ended, which is the current lp
		}

		else if (*tp != 0 && *lp == 0)
			return count; //found end of line, so there are no more characters for target to check
			
		else if (*tp == 0 && *lp == 0)
			return count++; //both target and line end at same time; increment count and return
		else 
		{
			tp = target; //reset tp to beginning of target
			start++; //start at position after target found last match
		}
	}
	

}


/* 
 * Function that will be executed by worker threads.
 * do "forever":  Get a filename from the queue.
 *   If it's a directory, walk through it and add a copy of
 *   each name to the queue. Else (file) read each line
 *   and scan for occurrences of searchstring.
 */
void *worker(void *ignored)
{
  char *name;
  struct stat finfo;
  FILE *f;
  //pthread_mutex_lock(&turnlock);
	  for (;;) 
	 
	  {
		 //pthread_mutex_lock(&turnlock);
		 name = NULL;
		 name = fq_get(&jobq);//get file name from queue
		 if(name == NULL) break;
		 pthread_mutex_lock(&turnlock);

		 if(stat(name, &finfo) == -1)
		 {
			 fprintf(stderr,"error finding stat information");
			 exit(1);
		 }
		
		 if(S_ISREG(finfo.st_mode))
		 {
			
			 char line[MAXLINE];

			 //pthread_mutex_lock(&turnlock);
			 printf("scanning %s\n", name);
			 f = fopen(name, "r");
			 nfiles++;

			 if(f == NULL)
			 {
				 printf("stderr: unable to open file");
				 exit(1);
			 }

			 while(fgets(line, MAXLINE, f) != NULL)
			 {
				 int scount = 0;
				 scount = checkline(line, searchstring);
				 

				 total += scount;



			 }
			 printf("scanned %d; found %d occurrences. \n", nfiles, total);
			 fflush(stdout);

			
			 free(name);
			 fclose(f);
			 //pthread_mutex_unlock(&turnlock);
			 //pthread_cond_signal(&myturn);



		 }
		

		 else if(S_ISDIR(finfo.st_mode))
		 {
			 DIR *directory;
			 struct dirent *dir;
			 
			 directory = opendir(name);

			 if (directory == NULL)
			 {
			 	fprintf(stderr, "Error opening Directory");
				exit(1);
			 }

			 //read from directory
			 while ((dir = readdir(directory)) != NULL)
			{

				if(!strcmp(dir->d_name, "."))
					 continue;

			 	if(!strcmp(dir->d_name, ".."))
					 continue;
				 
				
				 char * p = malloc(NAMESIZE);
				 snprintf(p, NAMESIZE, "%s/%s", name, dir->d_name);
				 printf("adding %s \n", p);	
				 fq_add(&jobq, p);
			 }
			 free(name);
			 closedir(directory);
		 }
		 else{/*ignore*/}
		 pthread_mutex_unlock(&turnlock);
		 pthread_cond_signal(&myturn);
	  }
	//pthread_mutex_unlock(&turnlock);
	//pthread_cond_signal(&myturn);
;
  // loop until main thread exits
    /* YOUR CODE HERE -- see project description */
    /* get a filename, stat it
     * - if it is a regular file, count the occurrences of the search string
     * - if a directory, add each filename it contains to the queue
     * - otherwise, ignore it.
     */
}


/* main thread:
 *  argv[1] is # of threads
 *  argv[2] is search string - store pointer in global "searchstring"
 *  argv[3], argv[4], ... are names of files to search.
 */
int main(int argc, char *argv[])
{
  int i,N;
  pthread_t *tids;
  
  if (argc < 4) {
    fprintf(stderr,"Usage: %s <#threads> <target> <file1> [<file2> ...]\n",
	    argv[0]);
    exit(1);
  }
  /* argc >= 4 */
  N = atoi(argv[1]); /* XXX check range */
  tids = (pthread_t *)calloc(N,sizeof(pthread_t));
  searchstring = argv[2];

  /* YOUR CODE HERE: Initialize jobq, mutex and cond var */
  fq_init(&jobq, N);
  
  if(pthread_mutex_init(&turnlock, NULL)) //or &turnlock
  {
	  fprintf(stderr,"mutex init failed");
	  exit(1);
  };
  if(pthread_cond_init(&myturn, NULL))
  {
	  fprintf(stderr,"condition init failed");
	  exit(1);
  }


  for (i=3; i<argc; i++)
  {	
	char *space = malloc(NAMESIZE);
	strcpy(space, argv[i]);
	fq_add(&jobq, space);
  }
  
  for (i=0; i<N; i++)
  {
	  if (pthread_create(&tids[i], NULL, worker, NULL))
	  {
		  fprintf(stderr," p_thread_create() failed\n");
		  exit(1);
	  }
    /* YOUR CODE HERE - create N threads */
  }

  pthread_mutex_destroy(&turnlock);
  fq_finish(&jobq);
  exit(0); // this kills all threads
}
      
